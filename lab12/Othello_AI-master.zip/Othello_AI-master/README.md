# Othello_AI
An AI program to play Othello game. Use DQN, Double-DQN, Dueling DQN and MCTS. By Chengzhe XU and Hao XIANG.
